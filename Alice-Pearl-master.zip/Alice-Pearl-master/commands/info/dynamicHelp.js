const { discord, MessageEmbed } = require('discord.js');
const recon = require('reconlx')
const ReactionPages = recon.ReactionPages

module.exports = {
    name: "help",
    aliases: ["h"],
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

        const page1 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Alice Pearl Help!')
        .setDescription('Heya Im Alice Pearl and you can find all of my commands below!\n\nUse the emojis to hower over pages.\n\n<a:number1_cake:828308638782849084>₊˚ʚ<:__cupcake2:826504553099690004>୧・ʚ︰**Info Help**\n\n<a:number2_cake:828308631937875978>₊˚ʚ<:__cake_roll1:826504780921831455>୧・ʚ︰**Fun Help**\n\n<a:number3_cake:828308638312955955>₊˚ʚ<a:__cake4:826504785947263006>୧・ʚ︰**Moderation Help**\n\n<a:number4_cake:828308643187130408>₊˚ʚ<a:__cake1:826504784667476018>୧・ʚ︰**Roleplay Help**\n\n<a:number5_cake:828308641136115762>₊˚ʚ<:__candy1:826504776341520495>୧・ʚ︰**Ticket Help**\n\n<a:number6_cake:828308641685176382>₊˚ʚ<a:__macaron1:826504556174245909>୧・ʚ︰**Utility Help**\n\n<a:number7_cake:828308642317991961>₊˚ʚ<a:__donut:826504556930269256>୧・ʚ︰**Miscellaneous Help**')
        .setColor('#FFC0CB')
        .setImage('https://cdn.discordapp.com/attachments/794221375442649088/826514538257711174/20210330_232241.png')
        .setTimestamp()
        
        const page2 = new MessageEmbed()
        .setTitle('<:__cupcake2:826504553099690004> Info Help!')
        .setDescription('`ping`: Shows the current ping of the bot.\n\n`stats`: Shows the details about the bot.\n\n`avatar`: Displays avatar of an user.\n\n`channelinfo`: Displays the details about a channel.\n\n`joinposition`: Displays a users join position.\n\n`permissions`: Returns the permission of a mentioned user.\n\n\`serverinfo`: DIsplays the information about the server.\n\n`servericon`: Displays the current server icon.\n\n`vote`: Vote for our server.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page3 = new MessageEmbed()
        .setTitle('<:__cake_roll1:826504780921831455> Fun Help!')
        .setDescription('`8ball`: Ask the 8ball about your future.\n\n`banner`: Creates a banner with the given text.\n\n`changemymind`: Creates a change my mind image with text.\n\n`emojify`: Makes the bot say your text with emojis.\n\n`guess`: Starts a fun guess the number game.\n\n`hangman`: Starts a hangman game with the given word.\n\n `meme`: Generates a random meme.\n\n`textart`: Generates an art with your message.\n\n`tictactoe`: Starts a fun tictactoe game.\n\n`triggered`: Generates a triggered image of yourself/mentioned user.\n\n`trivia`: Starts a fun trivia session.\n\n`trumptweet`: Makes trump tweet something.\n\n`cat`: Generates a random cat gif.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page4 = new MessageEmbed()
        .setTitle('<a:__cake4:826504785947263006> Moderation Help!')
        .setDescription('`kick`: Kicks a member from the guild.\n\n`ban`: Bans a member from the guild.\n\n`unban`: Unbans a member from the guild.\n\n`clear`: Deletes a specific amount of messages in a channel.\n\n`purge`: Deletes a given amount of messages of a mentioned member.\n\n`antivc`: Prevents a member from joining Vc.\n\n`un-antivc`: Allows a member to join vc again.\n\n`pull`: Pulls a mentioned user to your vc.\n\n`change-nickname`: Changes the nickname of the mentioned user.\n\n`reset-nickname`: Resets the nickname of the mentioned user.\n\n`mute`: Mutes a user from the guild.\n\n`tempmute`: Mutes a user from the guild for a given amount of time.\n\n`unmute`: Unmutes a muted user.\n\n`warn`: Warns a user.\n\n`warns`: List the warns of a mentioned user.\n\n`remove-warn`: Removes a specific warn of an user.\n\n`clearwarns`: Removes the complete warn log of an user.\n\n`lockchannel`: Locks the channel.\n\n`unlockchannel`: Unlocks the channel.\n\n`nuke`: Delete the current channel and creates an exact clone of the channel.\n\n`slowmode`: Updates the slowmode for channels.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page5 = new MessageEmbed()
        .setTitle('<a:__cake1:826504784667476018> Roleplay Help!')
        .setDescription('`cry`: Cry of something or someone.\n\n`hug`: Hug someone.\n\n`sad`: Feel sad of something or someone.\n\n`shoot`: Shoot someone.\n\n`slap`: Slap someone.\n\n`wave`: Wave at someone.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page6 = new MessageEmbed()
        .setTitle('<:__candy1:826504776341520495> Ticket Help!')
        .setDescription('`ticket`: Opens a ticket for support.\n\n`close`: Closes a ticket. (Admin only!)')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page7 = new MessageEmbed()
        .setTitle('<a:__macaron1:826504556174245909> Utility Help!')
        .setDescription('`nick`: Changes your nickname.\n\n`addrole`: Adds a specfic role to an user.\n\n`removerole`: Removes a specific role from an user.\n\n`announce`: Sends an announce message.\n\n`apply`: Lets a member to apply for staff.\n\n`binary`: Lets you encode or decode binary numbers. \n\n`birthday`: Displays the birthday date of a member.\n\n`firstmessage`: Displays the topmost message the channel\n\n`randomavatar`: Returns some random avatars of users from the guild.\n\n`report`: Lets you report some issues to the management team.\n\n`say`: sends a message through the bot.\n\n`suggest`: Lets you provide us some valuable suggestions.\n\n`translate`: Translates any given word/sentence to english.\n\n`urban`: Fetches some definitions of a given word from urban dictionary.\n\n`enlarge`: Enlarges the given emoji.\n\n`timer`: Starts a timer with the given time.\n\n`remind`: Sets a reminder with the given time and reason.\n\n`weather`: Displays the weather in a specific region.\n\n`afk`: Sets your status as AFK.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const page8 = new MessageEmbed()
        .setTitle('<a:__donut:826504556930269256> Miscellaneous Help!')
        .setDescription('`dm`: Sends a dm with the bot.\n\n`cc-create`: Creates a custom command.\n\n`cc-delete`: Deletes a custom command.\n\n`cc-list`: Displays the custom commands available in this guild.\n\n`asuggestion`: Accepts a sugesstion.\n\n`dsuggestion`: Denies a suggestion.\n\n`cmd-enable`: Enables a specific command of this bot in this guild.\n\n`cmd-disbale`: Disbales a specific command of the bot in this guild.\n\n`createchannel`: Creates a new channel with the name provided.\n\n`deletechannel`: Deletes a mentioned channel.\n\n`setwelcomechannel`: Sets a mentioned channel as the welcome channel.\n\n`checkwelcomechannel`: Checks the welcome channel.\n\n`fetchbans`: Displays the list of banned members from the guild.\n\n`members`: Displays the list of members joined with their positions.\n\n`setbirthday`: Sets your birthday.')
        .setColor('#FFC0CB')
        .setTimestamp()

        const pages = [
            page1,
            page2,
            page3,
            page4,
            page5,
            page6,
            page7,
            page8
        ]

        const textPageChange = true

        const emojis = ["⬅️", "➡️"]

        const timeout = 30000

        ReactionPages(message, pages, textPageChange, emojis, timeout)
    },
};