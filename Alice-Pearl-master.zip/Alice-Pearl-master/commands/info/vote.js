const { Client, Message, MessageEmbed } = require("discord.js");
module.exports = {
  name: "vote",
  aliases: ["v"],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
      //https://top.gg/servers/807676386005090374/vote

      const embed = new MessageEmbed()
          .setTitle(`<:zz_pinkstars:826520739275341854> Vote for **${message.guild.name}**!`)
          .addFields(
            {name: '__top.gg__', value: '[Vote Now!](https://top.gg/servers/807676386005090374/vote)'},
            {name: '__Rewards__', value:'- A special role for voters.'}
          )
          .setDescription(`Thank you for spending your valuable time to vote for us! Hope you're having a good day :)`)
          .setColor('#FFC0CB')
          .setThumbnail(message.guild.iconURL({ dynamic: true }))
          .setTimestamp();

          message.channel.send(embed);
  },
};