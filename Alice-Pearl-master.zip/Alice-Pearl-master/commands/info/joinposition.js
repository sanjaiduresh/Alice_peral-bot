const { Client, Message, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'joinposition',
    /**
     * @param {Client} client
     * @param {Message} message
     */

     run: async (client, message, args) => {
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

         if(!member) return message.reply('<:excl:819930667974131712> Please specify a member!');

         const members = message.guild.members.cache
            .sort((a, b) => a.joinedTimestamp - b.joinedTimestamp)
            .array();
        
         const position = new Promise((ful) => {
             for (let i = 1; i < members.length + 1; i++) {
                 if(members[i - 1].id === member.id) ful(i);
             }
         });

         message.channel.send(`**${member.user.tag}**'s join position <a:CP_Arrow:826668568145952812> **${await position}**`)
     },
};