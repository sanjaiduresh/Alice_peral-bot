const { Message, Client, MessageAttachment} = require('discord.js')
const fs = require('fs')

module.exports = {
    name : 'close',
    /**
     * @param {Client} client
     * @param {Message} message
     */
    run: async(client, message) => {
        if(message.channel.parentID !== '826025223966294068') return message.channel.send('You can only use this command in a ticket!');
        const transcriptChannel = message.guild.channels.cache.get('826025666272952331')
        message.channel.send('Deleting ticket in 5 seconds.....');
        
        client.ticketTranscript.findOne({
        Channel: message.channel.id
        }, async(err, data) => {
        if(err) throw err;
        if(data) {
            fs.writeFileSync(`../${message.channel.id}.txt`, data.Content.join("\n\n"))
            transcriptChannel.send(`${message.guild.members.cache.get(message.channel.name).user.username}'s ticket have been closed.`)
            await transcriptChannel.send(new MessageAttachment(fs.createReadStream(`../${message.channel.id}.txt`)));
            client.ticketTranscript.findOneAndDelete({
                Channel: message.channel.id
            })
        }
        })
        
        
        setTimeout(() => {
        message.channel.delete()
        }, 5000)
        }
}