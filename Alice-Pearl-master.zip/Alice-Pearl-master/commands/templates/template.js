const { Client, Message, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'template',
    aliases: ['temp', 'templates', 'temps'],
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {

        const catEmbed = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .setDescription('**Available Categories:** \n\n<:dotdot1:826520657486544896> Aesthetic \n<:dotdot1:826520657486544896> Community \n<:dotdot1:826520657486544896> Roleplay \n<:dotdot1:826520657486544896> Gaming \n<:dotdot1:826520657486544896> Development \n<:dotdot1:826520657486544896> Others \n\n Use `,template <category>` to view templates based on their category.')
        .setColor('#FFC0CB')

        message.channel.send(catEmbed);
    },
};