const { Client, Message, MessageEmbed } = require('discord.js');
const paginationEmbed = require('discord.js-pagination');

module.exports = {
    name: 'template-community',
    aliases: ['temp-community'],
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {


        const page1 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Office Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/zNrrad4WAGCR'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841972947454525441/Capture.PNG')
        .setColor('#FFC0CB')

        const page2 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Aesthetic Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/rdZQVf9F27t6'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841973296023207936/Capture.PNG')
        .setColor('#FFC0CB')

        const page3 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Amazing Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/8zDVR2D8nA4W'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841979693997621248/Capture.PNG')
        .setColor('#FFC0CB')

        const page4 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Advanced Among us"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/JBVr2qvqJQ6y'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841979933524754462/Capture.PNG')
        .setColor('#FFC0CB')

        const page5 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "All in One Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/WyFeMrNHCrgg'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841980107384160256/Capture.PNG')
        .setColor('#FFC0CB')

        const page6 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/MXFkF6PsqF5f'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841980318533681182/Capture.PNG')
        .setColor('#FFC0CB')

        const page7 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/Y37vpJPXMbED'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841981428577075200/Capture.PNG')
        .setColor('#FFC0CB')

        const page8 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Small Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/4bKRUYKMJh83'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841982128110698496/Capture.PNG')
        .setColor('#FFC0CB')

        const page9 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Follium Core's Discord template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/YAzqdzxkEx2u'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841982346516889600/Capture.PNG')
        .setColor('#FFC0CB')

        const page10 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Small Community server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/WY8MZfzq8Eny'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841983150968274965/Capture.PNG')
        .setColor('#FFC0CB')

        const page11 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Small Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/KcABxNvAuCgE'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841984376177688606/Capture.PNG')
        .setColor('#FFC0CB')

        const page12 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "tutor"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/BhVDxPstzG3T'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841985660634136596/Capture.PNG')
        .setColor('#FFC0CB')

        const page13 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Nexo"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/XCB7E6N4kknV'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841987884815089694/Screenshot_20210512_160832.png')
        .setColor('#FFC0CB')

        const page14 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "History"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/tA5h9gRSsUaz'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841988434507857930/Screenshot_20210512_161045.png')
        .setColor('#FFC0CB')

        const page15 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Great A&O Stuff"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/tQPUVxdhVdHz'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841988848275816498/Screenshot_20210512_161225.png')
        .setColor('#FFC0CB')

        const page16 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "HCF Template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/VQ24QSmJzED9'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841989268167720970/Screenshot_20210512_161406.png')
        .setColor('#FFC0CB')

        const page17 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Simple Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/TFuF6MpvBKbG'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841989670333054977/Screenshot_20210512_161554.png')
        .setColor('#FFC0CB')

        const page18 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community 3"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/wkkuXBmG3HWU'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841990413525975060/Screenshot_20210512_161846.png')
        .setColor('#FFC0CB')

        const page19 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Nostalgi's Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/s9AXguZb3r9P'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841990780230696980/Screenshot_20210512_162002.png')
        .setColor('#FFC0CB')

        const page20 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "City Themed Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/sV73xxSAKXMS'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841991288747196416/Screenshot_20210512_162142.png')
        .setColor('#FFC0CB')

        const page21 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community Server | 1"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/3FRCXFZ4swqK'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841991677110386698/Screenshot_20210512_162344.png')
        .setColor('#FFC0CB')

        const page22 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Satisfy's discord general template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/U4JbDn5cgfDE'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841980909309919232/Capture.PNG')
        .setColor('#FFC0CB')

        const page23 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "The Intentional Community"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/xg8eHYjwVWuq'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841992580363190272/Screenshot_20210512_162658.png')
        .setColor('#FFC0CB')

        const page24 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "The Basement"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/my2zJXrwJfX2'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841992952757878784/Screenshot_20210512_162854.png')
        .setColor('#FFC0CB')

        const page25 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "ChewyTheGoon"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/4wBStWG5FPNh'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841993716070744084/Screenshot_20210512_163143.png')
        .setColor('#FFC0CB')

        const page26 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Anime Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/x644ker8WWBG'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841996176538599474/Screenshot_20210512_164114.png')
        .setColor('#FFC0CB')

        const page27 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Amazing Community Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/2kxDwdMJjKmb'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/793523118383562782/848537359574499348/Screenshot_20210530_175355.png')
        .setColor('#FFC0CB')

        const page28 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/Y37vpJPXMbED'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854354034373820426/Screenshot_20210615_190707.png')
        .setColor('#FFC0CB')

        const page29 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Fancy and Simple Template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/AggtNdkDvs33'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854354660617355264/Screenshot_20210615_191002.png')
        .setColor('#FFC0CB')

        const page30 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Bolt's Realm"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/RkY2MfRjndrN'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854355337692053544/Screenshot_20210615_191224.png')
        .setColor('#FFC0CB')

        const page31 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Chill's Template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/cvp5DwebMRfK'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854355859743834142/Screenshot_20210615_191422.png')
        .setColor('#FFC0CB')

        const page32 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/bM3K83cpuqhj'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854356675350495252/Screenshot_20210615_191617.png')
        .setColor('#FFC0CB')

        const page33 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community server for all"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/D6fE9F7kNPEH'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854357279301173278/Screenshot_20210615_192006.png')
        .setColor('#FFC0CB')

        const page34 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community template (Emoji Style)"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/bdzgNJ2bkBck'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854357731375579176/Screenshot_20210615_192146.png')
        .setColor('#FFC0CB')

        const page35 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Anime"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/DBX2zu7aTeM3'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854358139834466364/Screenshot_20210615_192339.png')
        .setColor('#FFC0CB')

        const page36 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Professional Example Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/aRjCp2Acd8dq'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854358491280048128/Screenshot_20210615_192500.png')
        .setColor('#FFC0CB')

        const page37 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Unique Social Community Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/NqxzMDQ5bPgc'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854358844129542154/Screenshot_20210615_192627.png')
        .setColor('#FFC0CB')

        const page38 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Streaming Discord Template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/TyufNMxnznyj'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854359244995690526/Screenshot_20210615_192758.png')
        .setColor('#FFC0CB')

        const page39 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Simple/minimalist Template V2"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/2FsvXZbcsw7m'},
            { name: "Credits", value: 'luli.#7732'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854359860787675136/Screenshot_20210615_192945.png')
        .setColor('#FFC0CB')

        const page40 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Simple/minimalist Template"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/BSMjBNAYK4gG'},
            { name: "Credits", value: 'luli.#7732'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854361657521209405/Screenshot_20210615_193752.png')
        .setColor('#FFC0CB')

        const page41 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Shiny sparkle server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/aJJQMfNZujjT'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854362089287319562/Screenshot_20210615_193934.png')
        .setColor('#FFC0CB')

        const page42 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "GG"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/9Ce4H7R3ZQZG'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854362487322443826/Screenshot_20210615_194102.png')
        .setColor('#FFC0CB')

        const page43 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Christmas Party"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/rrXVza8gMfSK'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854362965188935701/Screenshot_20210615_194254.png')
        .setColor('#FFC0CB')

        const page44 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Advanced Private Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/EaJx6N83Pee9'},
            { name: "Credits:", value: 'Visual#0001'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854363664814309396/Screenshot_20210615_194433.png')
        .setColor('#FFC0CB')

        const page45 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community/Friends"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/63ytqvURwX4p'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854364010270556210/Screenshot_20210615_194700.png')
        .setColor('#FFC0CB')

        const page46 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Community Server"},
            { name: "Category:", value: "Community"},
            { name: "Link:", value: 'https://discord.new/SfS3hGHVX4AA'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/854364412072427520/Screenshot_20210615_194834.png')
        .setColor('#FFC0CB')

        const pages = [
            page1,
            page2,
            page3,
            page4,
            page5,
            page6,
            page7,
            page8,
            page9,
            page10,
            page11,
            page12,
            page13,
            page14,
            page15,
            page16,
            page17,
            page18,
            page19,
            page20,
            page21,
            page22,
            page23,
            page24,
            page25,
            page26,
            page27,
            page28,
            page29,
            page30,
            page31,
            page32,
            page33,
            page34,
            page35,
            page36,
            page37,
            page38,
            page39,
            page40,
            page41,
            page42,
            page43,
            page44,
            page45,
            page46
        ]

        const emojiList = ["⬅️", "➡️"]

        const timeout = 300000

        paginationEmbed(message, pages, emojiList, timeout);
  },
};