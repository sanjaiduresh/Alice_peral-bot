const { Client, Message, MessageEmbed } = require('discord.js');
const paginationEmbed = require('discord.js-pagination');

module.exports = {
    name: 'template aesthetic',
    aliases: ['temp-aesthetic', 'templates-aesthetic', 'temp-aes'],
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async(client, message, args) => {

        const page = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Cute Aesthetic template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/2hSh6fBx2P8W'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841995513787711528/Screenshot_20210512_163634.png')
        .setColor('#FFC0CB')

        const page1 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Autumn Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/jVwAcZBMsbnj'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841293412257759242/Screenshot_20210510_180911.png')
        .setColor('#FFC0CB')

        const page2 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Rainbowie Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/ZzXGaYvr4bdf'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841297027391684658/Screenshot_20210510_182315.png')
        .setColor('#FFC0CB')

        const page3 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Kitty Cafe"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/nquYg7Dz6uzV'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841298285918289960/Screenshot_20210510_182749.png')
        .setColor('#FFC0CB')

        const page4 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Pink Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/vEMq4J7gpvvd'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage("https://cdn.discordapp.com/attachments/789492065473265684/841321031662698496/Screenshot_20210510_195848.png")
        .setColor('#FFC0CB')

        const page5 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Bunny Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/DAwjHAQyRVAh'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841299793385226270/Screenshot_20210510_183429.png')
        .setColor('#FFC0CB')

        const page6 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Softie Aesthetic"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/U8qj2wrGvaWZ'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841300565938012181/Screenshot_20210510_183717.png')
        .setColor('#FFC0CB')

        const page7 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Cutesy Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/WfPKjzMrXpxG'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841301060886200350/Screenshot_20210510_183914.png')
        .setColor('#FFC0CB')

        const page8 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Froopy"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/wPkxB44S2YtP'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841301545248227410/Screenshot_20210510_184119.png')
        .setColor('#FFC0CB')

        const page9 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Soft Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/E2m5yQ8ydAC8'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841302013127426098/Screenshot_20210510_184314.png')
        .setColor('#FFC0CB')

        const page10 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Red Aesthetic Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/cEHApE4FFpTW'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841304620776292382/Screenshot_20210510_185253.png')
        .setColor('#FFC0CB')

        const page11 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Red/White Aesthetic Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/sgtSrtVCbE99'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841305643117969408/Screenshot_20210510_185537.png')
        .setColor('#FFC0CB')

        const page12 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Red Aesthetic"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/dDbQrQthHQcX'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841306660705271848/Screenshot_20210510_190151.png')
        .setColor('#FFC0CB')

        const page13 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Trading Template (Brown Themed)"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/CWPQEPncbC8B'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841307740713910302/Screenshot_20210510_190444.png')
        .setColor('#FFC0CB')

        const page14 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Nature based Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/fb7Y43znVucC'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841308222631313418/Screenshot_20210510_190801.png')
        .setColor('#FFC0CB')

        const page15 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Bakery Themed"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/3e4GUudfBsS3'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841309344745914388/Screenshot_20210510_191220.png')
        .setColor('#FFC0CB')
        
        const page16 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Pink Aesthetic"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/JzN9xEzsrAyU'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841310037862907944/Screenshot_20210510_191511.png')
        .setColor('#FFC0CB')

        const page17 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Nursecore Template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/Ef8yybGqpw26'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841310664517484544/Screenshot_20210510_191735.png')
        .setColor('#FFC0CB')

        const page18 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Edgy emo template"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/Jd4drsep8JSE'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841311159566204938/Screenshot_20210510_191945.png')
        .setColor('#FFC0CB')

        const page19 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Purple Aesthetic"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/cnRdfSB2PT3G'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841312104442101820/Screenshot_20210510_192333.png')
        .setColor('#FFC0CB')

        const page20 = new MessageEmbed()
        .setTitle('<a:__a04:826504777264791573> Astral Templates')
        .addFields(
            { name: "Name:", value: "Bakery Themed"},
            { name: "Category:", value: "Aesthetic"},
            { name: "Link:", value: 'https://discord.new/WryjxPK99n4z'}
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setImage('https://cdn.discordapp.com/attachments/789492065473265684/841984015837036564/Capture.PNG')
        .setColor('#FFC0CB')

        const pages = [
            page,
            page1,
            page2,
            page3,
            page4,
            page5,
            page6,
            page7,
            page8,
            page9,
            page10,
            page11,
            page12,
            page13,
            page14,
            page15,
            page16,
            page17,
            page18,
            page19,
            page20
        ]

        const emojiList = ["⬅️", "➡️"]

        const timeout = 300000

        paginationEmbed(message, pages, emojiList, timeout);
    },  
};