const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'info',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {

        message.channel.send(
            new MessageEmbed()
            .setDescription(`**__QUICK TOUR :__**

╭ ━・━・━・ʚ♡ɞ・━・━・━ ╮
            
:cherry_blossom:₊︰<#825970290759958568> : Make sure to read them!
:fish_cake:₊︰<#825970297496010752> : Find new friends.
:strawberry:₊︰<#825970297798131734> : Introduce yourself.
:bear:₊︰<#825970291636437042> : Grab roles of your choice.
            
╰ ━・━・━・ʚ♡ɞ・━・━・━ ╯
            
Enjoy your stay here :D`)
            .setColor('#303136')
            .setThumbnail(client.user.displayAvatarURL())
        )
    },
};