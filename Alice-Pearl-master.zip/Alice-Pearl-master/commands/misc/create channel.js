const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'createchannel',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(!message.member.permissions.has('MANAGE_CHANNELS')) return message.reply('<:excl:819930667974131712> You do not have persmission to use this command!');

        const channelNameQuery = args.join(" ");
        if(!channelNameQuery) return message.reply('<:excl:819930667974131712> Please specify a channel name!')

        message.guild.channels.create(channelNameQuery)
            .then(ch => {
                message.channel.send(`<a:tick:826520658426593380> ${ch} has been created!`);
            });
    }
}