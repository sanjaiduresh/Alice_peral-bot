const { Client, Message, MessageAttachment } = require("discord.js");
const canvas = require("discord-canvas");

module.exports = {
    name : "canvas",
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {

        if(!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:excl:819930667974131712> You do not have permissions to use this command');
        
        const image = new canvas.Welcome()
            .setUsername("Reks")
            .setDiscriminator("1723")
            .setMemberCount("17")
            .setGuildName("Testsss")
            .setAvatar(message.author.displayAvatarURL({ format: "png" }))
            .setColor("border", "#5A9F72")
            .setColor("username-box", "#5A9F72")
            .setColor("discriminator-box", "#5A9F72")
            .setColor("message-box", "#5A9F72")
            .setColor("title", "#5A9F72")
            .setColor("avatar", "#5A9F72")
            .setBackground(
                "https://img4.goodfon.com/original/1366x768/b/e7/firewatch-campo-santo-kholmy-vid-les-igra-peizazh-gory-pozha.jpg"
            )
            .toAttachment();
            const attachment = new MessageAttachment(
                (await image).toBuffer(),
                "goodbye-image.png"
            );

            message.channel.send(attachment);

    },
};