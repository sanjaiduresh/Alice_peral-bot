const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'accept-suggestion',
    aliases: ['asuggestion'],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.reply('<:excl:819930667974131712> You Dont have the permission to use this command');
        const messageID = args[0];
        const acceptQuery = args.slice(1).join(" ");

        if(!messageID) return message.reply('<:excl:819930667974131712> Please specify a message ID');
        if(!acceptQuery) return message.reply("<:excl:819930667974131712> Please specify a Reason!")
        try {
            const suggestionChannel = message.guild.channels.cache.get('830642164726890536');
            const suggestedEmbed = await suggestionChannel.messages.fetch(messageID);
            const data = suggestedEmbed.embeds[0];
            const acceptEmbed = new MessageEmbed()
                .setAuthor(data.author.name, data.author.iconURL)
                .setDescription(data.description)
                .setColor('#FFC0CB')
                .addField("Status (ACCEPTED)", acceptQuery);
            
            suggestedEmbed.edit(acceptEmbed);
            message.channel.send(new MessageEmbed()
            .setDescription(`<a:tick:826520658426593380> Accepted Suggestion!`).setColor('#FFC0CB')
        )

            const user = await client.users.cache.find((u) => u.tag === data.author.name);
            user.send('<a:tick:826520658426593380> Your Suggestion Has Been Accepted By a Moderator!');
        } catch(err) {
            console.log(err);
            message.channel.send('<:excl:819930667974131712> That Suggestion Does not Exist!')
        }
    }
}    