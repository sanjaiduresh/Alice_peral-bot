const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'deny-suggestion',
    aliases: ['dsuggestion'],
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.reply('<:excl:819930667974131712> You Dont have the permission to use this command');
        const messageID = args[0];
        const denyQuery = args.slice(1).join(" ");

        if(!messageID) return message.reply('<:excl:819930667974131712> Please specify a message ID');
        if(!denyQuery) return message.reply("<:excl:819930667974131712> Please specify a Reason!")
        try {
            const suggestionChannel = message.guild.channels.cache.get('830642164726890536');
            const suggestedEmbed = await suggestionChannel.messages.fetch(messageID);
            const data = suggestedEmbed.embeds[0];
            const denyEmbed = new MessageEmbed()
                .setAuthor(data.author.name, data.author.iconURL)
                .setDescription(data.description)
                .setColor("#FFC0CB")
                .addField("Status (DENIED)", denyQuery);
            
            suggestedEmbed.edit(denyEmbed);
            message.channel.send(new MessageEmbed()
            .setDescription(`Suggestion Denied!`).setColor('#FFC0CB')
        )

            const user = await client.users.cache.find((u) => u.tag === data.author.name);
            user.send('<a:cros_r:826520659181436948> Your Suggestion Has Been Denied By a Moderator!');
        } catch(err) {
            console.log(err);
            message.channel.send('That Suggestion Does not Exist!')
        }
    }
}    