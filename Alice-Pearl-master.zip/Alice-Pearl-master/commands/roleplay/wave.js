const Discord = require('discord.js');
var images = [
    "https://i.pinimg.com/originals/16/d7/c1/16d7c1dd8bc99b3b49a56d17679d5c74.gif",
    "https://i.pinimg.com/originals/05/6c/58/056c584d9335fcabf080ca43e583e3c4.gif",
    "https://i.pinimg.com/originals/05/6c/58/056c584d9335fcabf080ca43e583e3c4.gif",
    //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    "https://i.imgur.com/UcGioIH.gif",
    "https://i.imgur.com/TMaBtNt.gif",
    "https://i.imgur.com/VM9lRSw.gif",
    //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    "https://thumbs.gfycat.com/ArtisticVelvetyBarebirdbat-max-1mb.gif",
    "https://gifimage.net/wp-content/uploads/2017/09/anime-wave-gif-4.gif",
    "https://gifimage.net/wp-content/uploads/2017/10/hello-anime-gif-11.gif",
    "https://media3.giphy.com/media/S5L3aOgVqbzhK/giphy.gif",
    "https://cdn.weeb.sh/images/BJOBNi2R-.gif",
    "https://cdn.weeb.sh/images/Hy7MNi2Rb.gif",
    "https://cdn.weeb.sh/images/Skc7rj3AZ.gif",
    "https://cdn.weeb.sh/images/BJ0ZSonR.gif",
    "https://cdn.weeb.sh/images/ry8FIs30W.gif",
    "https://cdn.weeb.sh/images/HJNXNihAb.gif",
    "https://cdn.weeb.sh/images/tJ0QSs4R-.gif"



]

module.exports = {
    name: "wave",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        const user = message.mentions.users.first()
const image = images[Math.floor(Math.random() * images.length)]
const wavemessage = args.slice(1).join(' ')
        
if (!user) {
let wave_embed = new Discord.MessageEmbed()
.setAuthor(`${message.author.username} is waving`, message.author.displayAvatarURL({ dynamic: true}))
.setColor('#FFC0CB')
.setImage(image)
message.channel.send(wave_embed);
return
}
if (wavemessage.length > 0) {
let wave_embed = new Discord.MessageEmbed()
.setAuthor(`${message.author.username} is waving at ${user.username} "${wavemessage}\"`, message.author.displayAvatarURL({ dynamic: true}))
.setColor('#FFC0CB')
.setImage(image)
message.channel.send(wave_embed);
return
}
if (user.id === message.author.id) {
let wave_embed = new Discord.MessageEmbed()
.setAuthor(`${message.author.username} is waving at themselves`, message.author.displayAvatarURL({ dynamic: true}))
.setColor('#FFC0CB')
.setImage(image)
message.channel.send(wave_embed);
return
}
if (wavemessage == 0) {
let wave_embed = new Discord.MessageEmbed()
.setAuthor(`${message.author.username} is waving at ${user.username}`, message.author.displayAvatarURL({ dynamic: true}))
.setColor('#FFC0CB')
.setImage(image)
message.channel.send(wave_embed);
return
}
else {
let wave_embed = new Discord.MessageEmbed()
.setAuthor(`${message.author.username} waving ?`, message.author.displayAvatarURL({ dynamic: true}))
.setColor('#FFC0CB')
.setImage(image)
message.channel.send(wave_embed);
return
}
    },
};