const canvacord = require("canvacord");
const Discord = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
    name: "rank",
    aliases: ['level'],
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

        const target = message.mentions.users.first() || message.author;
        const user = await Levels.fetch(target.id, message.guild.id, true);
        const neededXp = Levels.xpFor(parseInt(user.level) + 1);
        if (!user) return message.channel.send("Seems like this user has not earned any xp so far.");
        

        //message.channel.send(`> **${target.tag}** is currently level ${user.level}.`);

        const rank = new canvacord.Rank()
            .setAvatar(target.displayAvatarURL({ dynamic: true, format: 'png' }))
            .setCurrentXP(user.xp)
            .setRequiredXP(neededXp)
            .setRank(user.position)
            .setLevel(user.level)
            .setProgressBar("#FFC0CB", "COLOR")
            .setUsername(target.username)
            .setDiscriminator(target.discriminator)
            .setStatus(message.author.presence.status, false, false)
            .setBackground("IMAGE", 'https://static.vecteezy.com/system/resources/previews/000/547/644/non_2x/abstract-pastel-sweet-color-blurred-background-with-bokeh-and-glitter-vector.jpg')

        rank.build()
            .then(data => {
                const attachment = new Discord.MessageAttachment(data, "RankCard.png");
                message.channel.send(attachment);
            });

    },
};