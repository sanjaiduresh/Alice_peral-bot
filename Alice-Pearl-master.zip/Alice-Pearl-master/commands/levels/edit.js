const Discord = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
    name: "edit",
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

        if(message.author.id !== '789483148526092348') return message.channel.send('<:excl:819930667974131712> This is an owner only command.');

        let usage = ",edit @member [xp, level] [add, set, remove] <value>"
        const mentionedMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if (!args[0]) return message.channel.send(`<:excl:819930667974131712> You need to state more arguments! **Usage**: \`${usage}\``);
        if (!mentionedMember) return message.channel.send('<:excl:819930667974131712> Please mention a valid member!');
        if (!args[1]) return message.channel.send(`<:excl:819930667974131712> You must state whether you are editing the **level** or **xp**! **Usage**: \`${usage}\``);
        if (!['xp', 'level'].includes(args[1])) return ('<:excl:819930667974131712> You have mention whether you are editing the **level** or **xp**!');

        if (args[1] == 'xp') {

            if (!['add', 'set', 'remove'].includes(args[2])) return message.channel.send(`<:excl:819930667974131712> You must state whether you are **adding**, **setting** or **removing** xp from the member! **Usage**: \`${usage}\``)

            const value = Number(args[3]);
            const levelUser = await Levels.fetch(mentionedMember.user.id, message.guild.id);
            if (!levelUser) return message.channel.send('<:excl:819930667974131712> I could not find any info of that user in my database');

            if (args[2] == 'add') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.appendXp(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Added: **${value}xp** to ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            } else if (args[2] == 'remove') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.subtractXp(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Removed: **${value}xp** from ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            } else if (args[2] == 'set') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.setXp(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Updated: **${value}xp** to ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            }

        } else if (args[1] == 'level') {

            if (!['add', 'set', 'remove'].includes(args[2])) return message.channel.send(`<:excl:819930667974131712> You must state whether you are **adding**, **setting** or **removing** level(s) from the member! **Usage**: \`${usage}\``)

            const value = Number(args[3]);
            const levelUser = await Levels.fetch(mentionedMember.user.id, message.guild.id);
            if (!levelUser) return message.channel.send('<:excl:819930667974131712> I could not find any info of that user in my database');

            if (args[2] == 'add') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.appendLevel(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Added: **${value} level(s)** to ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            } else if (args[2] == 'remove') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.subtractLevel(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Removed: **${value} level(s)** from ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            } else if (args[2] == 'set') {
                if (!value) return message.channel.send('<:excl:819930667974131712> The value you have stated is not a valid number');
                try {
                    await Levels.setLevel(mentionedMember.user.id, message.guild.id, value);
                    message.channel.send(`<a:tick:826520658426593380> Updated: **${value} level(s)** to ${mentionedMember.user.tag}`)
                } catch (err) {
                    console.log(err);
                }
            }

        }
    },
};