const Discord = require('discord.js');
const Levels = require('discord-xp');

module.exports = {
    name: "leaderboard",
    aliases: ['lb'],
    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {

        const rawLeaderboard = await Levels.fetchLeaderboard(message.guild.id, 5);

        if (rawLeaderboard.length < 1) return reply("Nobody's in leaderboard yet.");

        const leaderboard = await Levels.computeLeaderboard(client, rawLeaderboard, true);

        const lb = leaderboard.map(e => `${e.position} <:dotdot1:826520657486544896> Level **${e.level}** (${e.xp.toLocaleString()}xp) - ${e.username}#${e.discriminator}`); // We map the outputs.

        const leaderboardEmbed = new Discord.MessageEmbed()
        .setColor('#FFC0CB')
        .setAuthor('')
        .setDescription(`**Leaderboard For ${message.member.guild.name}** \n\n${lb.join("\n\n")}`)
        .setTimestamp()
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setFooter(client.user.username, client.user.displayAvatarURL({ dynamic: true }));

        message.channel.send(leaderboardEmbed);

    },
};