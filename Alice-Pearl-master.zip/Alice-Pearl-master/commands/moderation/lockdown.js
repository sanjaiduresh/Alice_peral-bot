const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
  name: "lockdown",
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    if(!message.member.permissions.has('ADMINISTRATOR')) return message.reply('You dont have permission to access this command!');

    const role = message.guild.roles.cache.get('808622896170663946');

    if(!args.length) return message.channel.reply('Please specify a query!');

    const query = args[0].toLowerCase();

    if(!['true', 'false'].includes(query)) return message.reply('The option you have stated is not valid!');

    const perms = role.permissions.toArray();

    if(query === "false") {
        perms.push('SEND_MESSAGES');
        console.log(perms)
        await role.edit({ permissions: perms });
        message.reply('Server is now unlocked!');
    } else {
        const newPerms = perms.filter((perm) => perm !== 'SEND_MESSAGES');
        console.log(newPerms);

        await role.edit({ permissions: newPerms });
        message.reply('Server is now under lockdown!');
    }
  },
};