const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
  name: "reset-nickname",
  aliases: ['rnn', 'reset-nick'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('<:excl:819930667974131712> You do not have permissions to use this command.')

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    if (!member) return message.reply("<:excl:819930667974131712> Please specify a member!");

    try {
      member.setNickname(null);
      message.channel.send(`<a:tick:826520658426593380> **Nickname** has been resetted Sucessfully!`)
    } catch (err) {
      message.reply(
        "<:excl:819930667974131712> I do not have permission to reset " + member.toString() + " nickname!"
      );
    }
  },
};