const { Client, Message, MessageEmbed } = require("discord.js");
const Discord = require('discord.js')
const ms = require('ms');

module.exports = {
	name: 'unlockchannel',
	description: 'This command is used for unlocking the channels.',
	usage: ',unlockchannel <duration>',
	/**
	 * 
	 * @param {Client} client 
	 * @param {Message} message 
	 * @param {String[]} args 
	 */
	run: async (client, message, args) => {

		if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:excl:819930667974131712> You do not have permission to use this command.')
		let notice3 = new Discord.MessageEmbed()
			.setDescription(
				`<a:cros_r:826520659181436948> **I don't have permission to manage channels!**`
			)
			.setColor("#FFC0CB");
		let dfgrdgdfgdf = new Discord.MessageEmbed()
			.setDescription(`<a:tick:826520658426593380> **Lockdown lifted**`)
			.setColor("#FFC0CB");

		if (!message.guild.member(client.user).hasPermission("MANAGE_CHANNELS"))
			return message.channel
				.send(`<a:cros_r:826520659181436948> **I don't have permission to manage channels!**`)
				.then(msg => msg.delete({ timeout: 5000 }));
		let mmqembed = new Discord.MessageEmbed()
			.setDescription(
				`<:excl:819930667974131712> ${message.author.username}, Missing Permission`
			)
			.setColor("#FFC0CB");
		if (!message.member.hasPermission("MANAGE_CHANNELS"))
			return message.channel
				.send(`<:excl:819930667974131712> ${message.author.username}, Missing Permission`)
				.then(msg => msg.delete({ timeout: 5000 }));

		if (!client.lockit) client.lockit = [];
		//if (!message.member.hasPermission("MANAGE_CHANNELS")) return msg.reply("❌**Error:** You don't have the permission to do that!");

		message.channel
			.createOverwrite(message.guild.id, {
				SEND_MESSAGES: true,
			})
			.then(() => {
				message.channel.send(`<a:tick:826520658426593380> **Lockdown lifted**`);
				delete client.lockit[message.channel.id];
			})
			.catch(error => {
				console.log(error);
			});
	},
};