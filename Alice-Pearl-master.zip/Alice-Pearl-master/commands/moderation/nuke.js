const { Message, MessageEmbed } =require('discord.js');

module.exports = {
    name: 'nuke',
    /**
     * @param {*} client
     * @param {Message} message
     * @param {*}
     */
    run: async(client, message, args) => {
        if(!message.member.hasPermission('ADMINISTRATOR')) return;
        if(!message.guild.me.hasPermission('MANAGE_CHANNELS')) return message.channel.reply('I Dont have permission to manage channels')

        message.channel.clone().then((ch) => {
            ch.setParent(message.channel.parent.id);
            ch.setPosition(message.channel.position);
            message.channel.delete();

            ch.send(new MessageEmbed()
                .setDescription('Channel Has Been **Nuked** Sucessfully').setColor('#FFC0CB')
            );
        })
    }
}