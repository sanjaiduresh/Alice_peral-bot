const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'un-antivc',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {

        if(!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:excl:819930667974131712> You do not have permission to use this command.')
        
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!target) return message.reply('<:excl:819930667974131712> Please specify a target!');

        const role = message.guild.roles.cache.find((role) => role.name.toLocaleLowerCase() === 'antivc');
        if(!role) return message.reply("<:excl:819930667974131712> The role doesn't exist!");
        
        if(!target.roles.cache.has(role.id)) return message.reply(`<a:cros_r:826520659181436948> ${target} is not anti vc-ed`);

        target.roles.remove(role.id)
        message.channel.send(`<a:tick:826520658426593380> ${target} has been un-antivced`);
    },
}