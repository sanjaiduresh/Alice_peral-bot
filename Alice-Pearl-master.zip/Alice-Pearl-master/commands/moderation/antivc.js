const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'antivc',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('<:excl:819930667974131712> You do not have permission to use this command!')

        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!target) return message.reply('<:excl:819930667974131712> Please specify a member!');

        let role = message.guild.roles.cache.find((role) => role.name.toLocaleLowerCase() === 'antivc');
        if(!role) {
            try {
                message.channel.send('Attempting to create an Antivc role!');
                role = await message.guild.roles.create({
                    data: {
                        name: 'antivc',
                        permissions: []
                    }
                })

                message.guild.channels.cache.filter((c) => c.type === 'voice').forEach(async (channel) => {
                    await channel.createOverwrite(role, {
                        VIEW_CHANNEL: true,
                        CONNECT: false
                    })
                })

                message.channel.send('<a:tick:826520658426593380> Role has been created!')
            } catch (error) {
                console.log(error)
            }
        }
        await target.roles.add(role.id);
        message.channel.send(`<a:tick:826520658426593380> ${target} has been anti vc-ed`)
    }
}