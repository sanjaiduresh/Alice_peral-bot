const { Client, Message, MessageEmbed, MessageFlags, ReactionUserManager } = require("discord.js");

module.exports = {
    name : 'pull',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(!message.member.permissions.has('MANAGE_CHANNELS')) return;

        const member = message.mentions.members.first();
        if(!member) return message.reply('<:excl:819930667974131712> Please mention a member!');
        if(!member.voice.channel) return message.reply('<:excl:819930667974131712> The mentioned member is not in a voice channel!');

        if(!message.member.voice.channel) return message.reply('<:excl:819930667974131712> Please join a voice channel to use this command!');
        member.voice.setChannel(message.member.voice.channel);

        message.channel.send('<a:tick:826520658426593380> Moved the member successfully!')
    },
};