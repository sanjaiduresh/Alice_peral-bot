const { Client } = require("discord.js");

module.exports = {
    name : 'ban',
    run : async(client, message, args) => {
        if(!message.guild.me.hasPermission('BAN_MEMBERS')) return message.channel.send('<:excl:819930667974131712> I Do Not Have Permission To ban Members')
        if(!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('<:excl:819930667974131712> You Do Not Have Permission To Ban Members!')
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!member) return message.channel.send('<:excl:819930667974131712> Please Specify a Member to ban')
        if(message.member.roles.highest.position <= member.roles.highest.position) return message.reply('<:excl:819930667974131712> You cant kick the mentioned member because your role is either equal or lower than the mentioned user!')

        const reason = args.slice(1).join(" ") || "No reason Provided";
        await member.ban({ reason })
        message.channel.send(`<a:tick:826520658426593380> ${member.user.tag} was banned sucessfully for ${reason}!`)
    }
}