const { MessageEmbed } = require('discord.js')
const Discord = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name : 'unban',
    category : 'moderation',
    description : 'Unbans a user with ID',

    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */

    run : async(client, message, args) => {
        
        if(!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('<:excl:819930667974131712> You Do Not Have Permission To Ban/Unban Members!')

		const id = args[0];
		if(!id) return message.reply('<:excl:819930667974131712> Please provide a valid User ID!');

		const bannedMenbers = await message.guild.fetchBans();
		if (!bannedMenbers.find((user) => user.user.id === id)) return message.reply('<:excl:819930667974131712> User is not Banned!')
		message.guild.members.unban(id);
		message.reply('<a:tick:826520658426593380> Unbanned user Sucessfully!')
    },
};