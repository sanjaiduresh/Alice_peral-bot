const { Client, Message, MessageEmbed, MessageFlags } = require("discord.js");
const Schema = require('../../models/chatbotChannel');

module.exports = {
    name : 'setchatbotchannel',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        if(message.author.id !== '789483148526092348') return message.channel.send('This is an owner only command.');

        const channel = message.mentions.channels.first() || message.channel;
        Schema.findOne({ Guild: message.guild.id }, async(err, data) => {
            if(data) data.delete();
            new Schema({
                Guild: message.guild.id,
                Channel:channel.id,
            }).save();
            message.channel.send(`<a:tick:826520658426593380> Saved Chatbot channel as ${channel}`);
        })
    },
};