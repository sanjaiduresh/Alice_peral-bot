const { Message } = require('discord.js')

module.exports = {
    name : 'addrole',
    run : async(client, message, args) => {

        /**
         * @param {Message} message
         */

        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('<:excl:819930667974131712> You do not have permission.')
        //next we define some variables
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!target) return message.channel.send('<:excl:819930667974131712> No member specified') 
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
        if(!role) return message.channel.send('<:excl:819930667974131712> No role specified')
        await target.roles.add(role) 
        message.channel.send(`<a:tick:826520658426593380> ${target.user.username} has obtained a role`)
    }
}