const { fetchTranscript } = require("reconlx");
const { MessageAttachment } = require('discord.js');
const client = require("../..");

module.exports = {
    name: "transcript",
    run: async (client, message, args) => {
        fetchTranscript(message, 10)
        .then((data) => {
            const File = new MessageAttachment(data, 'index.html')
            message.channel.send(File)
        })
    }
}