const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
  name: "nickname",
  aliases: ['nick'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    const member = message.member;

    const arguments = args.slice(0).join(" ");

    if (!arguments) return message.reply("<:excl:819930667974131712> Please specify a nickname!");

    try {
      member.setNickname(arguments);
      message.channel.send(`<a:tick:826520658426593380> **Nickname** has been changed Sucessfully!`)
    } catch (err) {
      console.log(err);
      message.reply(
        "<:excl:819930667974131712> I do not have permission to set " + member.toString() + " nickname!"
      );
    }
  },
};