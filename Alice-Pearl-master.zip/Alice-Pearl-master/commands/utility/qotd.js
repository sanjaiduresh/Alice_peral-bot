const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'qotd',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {

        if(!message.member.hasPermission('ADMINISTRATOR')) return

        qotdchannel = message.guild.channels.cache.get('854290265387565076');
        const qotd = args.slice(0).join(' ')
        const [ a1, a2, a3] = qotd.split('|');

        qotdchannel.send(`₊˚ʚ <:letq:819935836296183868><:leto:819935839286591499><:lett:819935838719967252><:letd:819930667311300648> ₊ <a:3247_Roses:819930666774560768> ˚๑꒱ **${a1}**
꒷꒦ <a:aa04:826504777264791573> ꒷︶꒦︶꒷꒦︶꒷ 🍰 ꒦︶꒷꒦
<:excl:819930667974131712> **Would you Rather....**
<:dash6:826520659911901214> ${a2}
<:dash6:826520659911901214> ${a3}
<:dash6:826520659911901214> React to the **emoji** of your answer.
꒷꒦꒷ <a:sfpink_lollipopp2:819930668380979212> ︶꒦ <@&761498467360178208> ꒷ ꒷꒦︶꒦ <:pink_star:819930666375970847> ꒷`)
        .then(function (msg) {
            msg.react('<:leta:819930665981444096>')
            msg.react('<:letb:819930664597454849>')
        })
    },
};