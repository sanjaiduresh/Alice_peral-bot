const { Discord, MessageEmbed } = require('discord.js');
const math = require('mathjs');

module.exports = {
    name :'calculate',
    aliases: ['calc', 'calculator'],
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        
        if (!args[0]) return message.channel.send("**Enter Something To Calculate**");

        let result;
        try {
            result = math.evaluate(args.join(" ").replace(/[x]/gi, "*").replace(/[,]/g, ".").replace(/[÷]/gi, "/"));
        } catch (e) {

            let invalid = new MessageEmbed()
            .setDescription("**Enter Valid Calculation!**\n\n**List of Calculations** - \n\n1. **sqrt equation** - `sqrt(3^2 + 4^2) = 5`\n2. **Units to Units** - `2 inch to cm = 0.58`\n3. **Complex Expressions Like** - `cos(45 deg) = 0.7071067811865476`\n4. **Basic Maths Expressions** - `+, -, ^, /, decimals` = **2.5 - 2 = 0.5**")
            .setColor('#FFC0CB')
            .setThumbnail(`${client.user.displayAvatarURL({ dynamic: true })}`)
            .setTimestamp();

            return message.channel.send(invalid);
        }

        let embed = new MessageEmbed()
            .setColor("#FFC0CB")
            .setAuthor(`${client.user.username} Calculator`)
            .addField("**Operation**", `\`\`\`Js\n${args.join("").replace(/[x]/gi, "*").replace(/[,]/g, ".").replace(/[÷]/gi, "/")}\`\`\``)
            .addField("**Result**", `\`\`\`Js\n${result}\`\`\``)
            .setThumbnail(`${client.user.displayAvatarURL({ dynamic: true })}`)
            .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
        message.channel.send(embed);
    },
};