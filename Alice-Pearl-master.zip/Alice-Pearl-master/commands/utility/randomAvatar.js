const { Message, Client, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'randomavatar',
    /**
     * @param {Client} client
     * @param {Message} message
     */
    run: async(client, message) => {
        const user = client.users.cache.random();

        message.channel.send(
            new MessageEmbed()
                .setColor('#FFC0CB')
                .setFooter(`${user.tag}'s avatar!`)
                .setImage(user.displayAvatarURL())
        )
    }

}