const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
  name: "remove-nickname",
  aliases: ['rnn', 'clear-nick'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
    const member = message.member;

    try {
      member.setNickname(null);
      message.channel.send(`<a:tick:826520658426593380> **Nickname** has been removed Sucessfully!`)
    } catch (err) {
      message.reply(
        "<:excl:819930667974131712> I do not have permission to reset " + member.toString() + " nickname!"
      );
    }
  },
};