const { Message } = require('discord.js')

module.exports = {
    name : 'removerole',
    run : async(client, message, args) => {
        
        /**
         * @param {Message} message
         */
        
        if(!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send('<:excl:819930667974131712> You do not have permission.')
        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]); 
        if(!target) return message.channel.send('<:excl:819930667974131712> No member specified') 
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
        if(!role) return message.channel.send('<:excl:819930667974131712> No role specified')
        await target.roles.remove(role) 
        message.channel.send(`<a:tick:826520658426593380> ${target.user.username} roles has been removed`) 
    }
}