const Discord = module.require("discord.js");
const ms = require("ms");

module.exports = {
    name :'timer',
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
		
		const timer = args[0]

		if(!args[0]) {
			return message.channel.send('<:excl:819930667974131712> Please specify a valid reminder time duration!')
		}

		message.reply(`<a:tick:826520658426593380> Timer has been set for: **${ms(ms(timer), {long: true})}**`)
		setTimeout(function() {
			message.channel.send(`<@${message.author.id}> <a:dp_bowpink:826511463266254858> Timer has ended! Lasted for: **${ms(ms(timer), {long: true})}**`)
		}, ms(timer))
    },
};