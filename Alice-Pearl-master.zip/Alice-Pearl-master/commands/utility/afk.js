const { Client, Message, MessageEmbed} = require('discord.js');
const { Database } = require('quickmongo');
const mongoDBURL = require('../../config.json').mongo
const quickmongo = new Database(mongoDBURL);

module.exports = {
    name: 'afk',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {
        let reason = args.join(" ");
        const AFKPrefix = '[AFK] ';

        if (!reason) reason = "No AFK reason provided!";

        const afkembed = new MessageEmbed()
        .setTitle(`${message.author.tag}`)
        .setDescription(`Your status has been set to AFK. \n\n**Reason:** ${reason}`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setColor('#FFC0CB')
        .setTimestamp();


        try {
            await quickmongo.set(`afk-${message.author.id}+${message.guild.id}`, reason);
            message.channel.send(afkembed)

        } catch (err) {
            console.log(err)
            message.channel.send('Could not set AFK Status');
        }

        try {
            await message.member.setNickname(AFKPrefix + message.member.user.username)
        } catch (err) {
            console.log(err)
        }
    },
};