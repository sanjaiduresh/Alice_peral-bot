const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'suggest',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        const suggestionQuery = args.join(" ");
        if(!suggestionQuery) return message.reply('Please specify a suggestion!')
        const embed = new MessageEmbed()
            .setAuthor(message.author.tag, message.author.displayAvatarURL ({ dynamic: true}))
            .setDescription(`**Suggestion**: ${suggestionQuery}`)
            .setColor('#FFC0CB')
            .setTimestamp()
            .addField("STATUS", "PENDING")

        message.reply('Submitted your Suggestion!')
        message.guild.channels.cache.get('830642164726890536').send(embed)

    }
}