const Discord = module.require("discord.js");
const ms = require("ms");

module.exports = {
    name :'reminder',
	aliases: ['remind'],
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
		
		const timer = args[0]

		if(!args[0]) {
			return message.channel.send('<:excl:819930667974131712> Please specify a valid reminder time duration!')
		}

		const reminder = args.join(" ").slice(args[0].length);

		if(reminder) {
			if(!args[1]) {
				return message.channel.send("<:excl:819930667974131712> You need to specify a reminder!")
			}
		}

		message.reply(`<a:tick:826520658426593380> Alright your reminder has been set. I will remind you in **${ms(ms(timer), {long: true})}**`)
		setTimeout(function() {
			message.member.send(`<a:dp_bowpink:826511463266254858> Reminder: **${reminder}**`)
		}, ms(timer))
    },
};