const { Client, Message, MessageEmbed } = require("discord.js");
const Schema = require('../../models/birthday');

module.exports = {
  name: "birthday",
  aliases: ['bday'],
  /**
   * @param {Client} client
   * @param {Message} message
   * @param {String[]} args
   */
  run: async (client, message, args) => {
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
      
      Schema.findOne({ User: user.id}, async(err, data) => {
          if(!data) return message.reply('<:excl:819930667974131712> User has not set their Birthday date!');
          message.channel.send(`<:__candy1:826504776341520495> **${user.user.tag}**'s Birthday is on **${data.Birthday}**`);
      });
  },
};