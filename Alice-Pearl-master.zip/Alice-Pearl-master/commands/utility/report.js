const { Client, Message, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'report',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        
        const query = args.join(" ");
        if(!query) return message.reply('Please specify a query!');

        const reportEmbed = new MessageEmbed()
            .setTitle('NEW REPORT!')
            .addField('Author', message.author.toString(), true)
            .addField('Guild', message.guild.name, true)
            .addField('Report', query)
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setColor('#FFC0CB')
            .setTimestamp();

            message.guild.channels.cache.get('825970295575674912').send(reportEmbed)
            message.channel.send('<a:tick:826520658426593380> Your report has been submitted sucessfully!')
    }
}