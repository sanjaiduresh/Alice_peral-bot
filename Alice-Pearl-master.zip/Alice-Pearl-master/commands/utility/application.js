const { Client, Message, Util, MessageEmbed } = require("discord.js");

module.exports = {
    name : 'apply',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {

        if(!message.member.roles.cache.get('725574842367213649')) return message.reply('You gotto be **Lv.5 or higher** to use this command! Check your rank using `.level`');
        
        const questions = [
            "Discord Username (include #number)",
            "How old are you?",
            "What country and timezone are you in?",
            "Why do you want to be a Discord Moderator in our Server?",
            "What prior moderator/administration experience do you have, if any?",
            "Are you familiar with all discord server rules and channel rules?",
        ];

        message.channel.send('<a:tick:826520658426593380> Check your Dms!');

        let collectCounter = 0;
        let endCounter = 0;

        const filter = (m) => m.author.id === message.author.id;

        const appStart = await message.author.send(questions[collectCounter++]);
        const channel = appStart.channel;

        const collector = channel.createMessageCollector(filter);

        collector.on("collect", () => {
            if(collectCounter < questions.length) {
                channel.send(questions[collectCounter++])
            } else {
                channel.send('Your application has been sent!')
                collector.stop("fulfilled");
            }
        });

        const appsChannel = client.channels.cache.get('825979821850361866'); 
        collector.on('end', (collected, reason) => {
            if(reason === 'fulfilled') {
                let index = 1;
                const mappedResponses = collected.map((msg) => {
                    return `${index++}) ${questions[endCounter++]}\nAns:** ${msg.content}**`;
                })
                .join("\n\n");
                
                appsChannel.send(
                    new MessageEmbed()
                        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
                        .setTitle('NEW APPLICATION!')
                        .setDescription(mappedResponses)
                        .setColor('#FFC0CB')
                        .setTimestamp()
                );
            }
        })
    },
};