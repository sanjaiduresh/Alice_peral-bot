const { Client, Message, Util, MessageEmbed } = require("discord.js");
const axios = require('axios')

module.exports = {
    name : 'urban',
    /**
     * 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        let query =args.join(" ");
        if(!query) return message.reply('<:excl:819930667974131712> Please specify a word to search!')

        query - encodeURIComponent(query);

        const { data: { list }} = await axios.get(`https://api.urbandictionary.com/v0/define?term=${query}`);

        const [ answer ] = list;

        message.channel.send(
            new MessageEmbed()
                .setTitle("URBAN DICTIONARY")
                .setColor('#FFC0CB')
                .addField("DEFINITION", trim(answer.definition))
                .addField("EXAMPLE", trim(answer.example))
                .addField("RATING", `${answer.thumbs_up} 👍`)
        );
    },
};

function trim(input) {
    return input.length > 1024 ? `${input.slice(0, 1020)} ...` : input;
}