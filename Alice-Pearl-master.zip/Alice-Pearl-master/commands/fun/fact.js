const { Discord, MessageEmbed } = require('discord.js');
const Random = require("srod-v2");

module.exports = {
    name :'fact',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        
        let Fact = await Random.GetFact("BLUE");
 	    message.channel.send(Fact);
    },
};