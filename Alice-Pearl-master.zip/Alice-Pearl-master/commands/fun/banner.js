const Discord = require('discord.js');

module.exports = {
    name: 'banner',
    description: 'Changes the text into banner',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {
        const word = args.slice(0).join('+');
        if (!word) return message.channel.send(`Please write!`)
        if (word > 666) return message.channel.send('Keep it under 666 words!')
        const link = `https://dummyimage.com/2000x500/33363c/ffffff&text=${word}`.replace(' ', '+')
        let embed = new Discord.MessageEmbed()
            .setTitle("Here's your Banner!")
            .setColor('#FFC0CB')
            .setImage(link)
            .setFooter(`Requested By ${message.author.username}`)
        message.channel.send(embed)
    },
};