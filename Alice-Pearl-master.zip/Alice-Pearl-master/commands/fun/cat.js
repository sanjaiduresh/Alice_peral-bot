const request = require("request");
const Discord = require("discord.js");

module.exports = {
    name :'cat',
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
        request("http://edgecats.net/random", function (error, response, body) {
		if (!error && response.statusCode == 200) {
			let emb = new Discord.MessageEmbed()
				.setImage(body)
				.setColor("#FFC0CB")
				.setTitle("Your random cat here")

			message.channel.send(emb);
		}
	});
    },
};