const { Discord, MessageEmbed } = require('discord.js');
const Random = require("srod-v2");

module.exports = {
    name :'why',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run : async(client, message, args) => {
        
        let Why = await Random.GetWhy("BLUE");
	    message.channel.send(Why);
    },
};