const { tictactoe } = require('reconlx')
const figlet = require('figlet')
module.exports = {
    name : 'textart',
    run : async(client, message, args) => {
        
        figlet.text(args.join(" "), {
            font: 'Ghost',
        }, async(err, data) => {
            message.channel.send(`\`\`\`${data}\`\`\``);
        });
    },
};