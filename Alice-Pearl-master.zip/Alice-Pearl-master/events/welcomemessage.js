const client = require('../index');
const { MessageEmbed } = require('discord.js');

client.on('guildMemberAdd', async(member) => {

    const Channel = member.guild.channels.cache.get('825970289250402304') //825970289250402304

    const embed = new MessageEmbed()
        .setDescription(`**ପ✧⊹︰Hi ${member.user.username} !! :cherry_blossom: 
・︶ ︶ ꒷ ︶ ︶ ꒷ ꒦ :fish_cake: 
・ ❏ ・Welcome to Astral! we're a small and humble lil community. We provide some tons of cool looking templates and a lot of channels for advertising to help your server grow, while making new friends along the way!
・︶ ︶ ꒷ ︶ ︶ ꒷ ꒦ :cherry_blossom: 

╭・(๑ •ω• ๑) Make sure to:
➣ Read the rules!
➣ Pick up some roles!
➣ Explore the server!
╰┈ :cherry_blossom:  ✦ And have fun!

・︶ ︶ ꒷ ︶ ︶ ꒷ ꒦ 
:fish_cake:  If you’re having any problems, please contact a staff member. Our team will get back to you shortly, thank you for your patience :cherry_blossom: 
₊˚︶˚₊꒷︶ :cherry_blossom: ๑‧˚₊꒷꒦︶ :・✦․**
`)
        .setImage('https://cdn.discordapp.com/attachments/794221375442649088/826266784663339028/20210330_065239.png')
        .setColor('#FFC0CB')
        .setTimestamp();

    Channel.send(`Welcome ${member.toString()} !!`, embed);
})