const client = require('../index');
const Discord = require("discord.js");
const akinator = require("discord.js-akinator");
const config = require('../config.json');
const PREFIX = config.prefix;

client.on("message", async message => {
    if(message.content.startsWith(`${PREFIX}akinator`)) {
        akinator(message);
    }
});