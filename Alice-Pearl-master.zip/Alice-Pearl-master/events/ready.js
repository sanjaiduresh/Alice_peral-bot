const client = require('../index')

client.on('ready',() => {
    console.log(`${client.user.username} has logged in`);

    const activities = [
        { name: 'your commands', type: 'LISTENING' }
    ];

    client.user.setPresence({ status: 'online',activity: activities[0] });
    
    let activity = 1;
    
    setInterval(() => {
       activities[1] = { name: `${client.users.cache.size} Astrals`, type: 'WATCHING' };
       activities[2] = { name: `,help for help!` };
       activities[3] = { name: `Developed by Reks`, type: 'STREAMING' };
       activities[4] = { name: `DM for Support!` };
       if (activity > 5) activity = 1;
       client.user.setActivity(activities[activity]); 
       activity++; 
    }, 15000);

})