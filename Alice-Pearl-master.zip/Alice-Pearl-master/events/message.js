const client = require('../index')
const {
    MessageEmbed
} = require('discord.js')
const config = require('../config.json')
const blacklist = require('../models/blacklist')
const prefix = config.prefix
const db = require('../models/command')
const schema = require('../models/custom-commands');

const Discord = require('discord.js');

const mongoDBURL = require('../config.json').mongo;
const Levels = require('discord-xp');
Levels.setURL(mongoDBURL);

client.on('message', async message => {
    if (message.author.bot) return;
    if (!message.guild) return;

    const target = message.mentions.users.first() || message.author;
    const use = await Levels.fetch(message.author.id, message.guild.id);
    const randomAmountOfXp = Math.floor(Math.random() * 24) + 1; // Min 1, Max 25
    const hasLeveledUp = await Levels.appendXp(message.author.id, message.guild.id, randomAmountOfXp);
    if (hasLeveledUp) {
        const user = await Levels.fetch(message.author.id, message.guild.id);
        message.channel.send(`${message.author}, Congratulations! You have leveled up to **${user.level}**. :tada:`);
    }

    if (use.level === 5) {
        message.member.roles.add('725574842367213649')
    } else if(use.level === 10) {
        message.member.roles.add('725574960512237688')
    } else if(use.level === 20) {
        message.member.roles.add('725575258798817280')
    } else if(use.level === 30) {
        message.member.roles.add('725989081418301465')
    } else if(use.level === 40) {
        message.member.roles.add('746674483313508365')
    } else if(use.level === 50) {
        message.member.roles.add('746675603561906198')
    };


    if (!message.content.startsWith(prefix)) return;
    blacklist.findOne({
        id: message.author.id
    }, async (err, data) => {
        if (err) throw err;
        if (!data) {
            if (!message.guild) return;
            if (!message.member) message.member = await message.guild.fetchMember(message);
            const args = message.content.slice(prefix.length).trim().split(/ +/g);
            const cmd = args.shift().toLowerCase();
            if (cmd.length == 0) return;
            const data = await schema.findOne({
                Guild: message.guild.id,
                Command: cmd
            });
            if (data) message.channel.send(data.Response);
            let command = client.commands.get(cmd)
            if (!command) command = client.commands.get(client.aliases.get(cmd));

            if (command) {
                const check = await db.findOne({
                    Guild: message.guild.id
                })
                if (check) {
                    if (check.Cmds.includes(command.name)) return message.channel.send('<:excl:819930667974131712> This command is Disabled By Admin')
                    command.run(client, message, args)
                } else {
                    command.run(client, message, args)
                }
            }
        } else {
            message.channel.send('<:excl:819930667974131712> You are blacklisted!')
        }
    })
})