const client = require('../index')
const ms = require('ms')
const Fs = require('fs')
const Discord = require('discord.js')
const usersMap = new Map();
const LIMIT = 5;
const TIME = 7000;
const DIFF = 3000;

client.on('message', async (msg) => {

    if (msg.author.bot) return;
    if (!msg.guild) return;
    if(message.member.hasPermission('ADMINISTRATOR')) return;
    if (msg.content.length >= 350) {

        if (msg.channel.id === '825970297798131734' || msg.channel.id === '826203955351912538' || msg.channel.id === '826204202283565056' || msg.channel.id === '826204619163172894' || msg.channel.id === '826204502188490783' || msg.channel.id === '826204263326941184' || msg.channel.id === '826204385133461554' || msg.channel.id === '826204843663294564' || msg.channel.id === '826204944792551495' || msg.channel.id === '826204445993336872' || msg.channel.id === '826204672318505060' || msg.channel.id === '830642266485030943') return
        msg.delete()
        msg.reply(`you are not allowed to send unnecessary long messages in this server. Continuing will result in a mute!`)

        var warnsJSON = JSON.parse(Fs.readFileSync('././warnInfo.json'))


        if (!warnsJSON[msg.author.id]) {
            warnsJSON[msg.author.id] = {
                warns: 0
            }

            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }

        warnsJSON[msg.author.id].warns += 1
        Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))


        setTimeout(function () {

            warnsJSON[msg.author.id].warns -= 1
            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }, ms('12h'))

        var warnEm = new Discord.MessageEmbed()
            .setColor('YELLOW')
            .setTitle(`You have been warned in ${msg.guild.name}`)
            .setDescription('You have recieved a warning from the moderation system')
            .addField('Reason', '[AutoMod] Bulk Messages')
            .addField('Expires', '12h')

        try {
            msg.author.send(warnEm)

        } catch (err) {

        }


        if (Number.isInteger(warnsJSON[msg.author.id].warns / 3)) {
            var mutedEm = new Discord.MessageEmbed()
                .setColor('RED')
                .setDescription(`**${msg.member.user.username}** has been muted for continuous infractions`)
            msg.channel.send(mutedEm)

            const muteRole = msg.guild.roles.cache.find(r => r.name === 'muted')
            const user = msg.member
            user.roles.add(muteRole.id)

            var yougotmuted = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle(`You have been muted in ${msg.guild.name}`)
                .setDescription('You have been muted after 3 infractions')
                .addField('Reason', 'Multiple AutoMod Infractions')
                .addField('Expires', '1h')

            try {

                msg.author.send(yougotmuted)

            } catch (err) {

            }

            setTimeout(function () {
                user.roles.remove(muteRole.id)
            }, ms('1h'));

        }
        return;

    }

    if (msg.mentions.users.size > 2) {

        msg.reply(`you cannot mass mention users in this server. Continuing will result in a mute!`)

        var warnsJSON = JSON.parse(Fs.readFileSync('././warnInfo.json'))


        if (!warnsJSON[msg.author.id]) {
            warnsJSON[msg.author.id] = {
                warns: 0
            }

            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }

        warnsJSON[msg.author.id].warns += 1
        Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))


        setTimeout(function () {

            warnsJSON[msg.author.id].warns -= 1
            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }, ms('12h'))

        var warnEm = new Discord.MessageEmbed()
            .setColor('YELLOW')
            .setTitle(`You have been warned in ${msg.guild.name}`)
            .setDescription('You have recieved a warning from the moderation system')
            .addField('Reason', '[AutoMod] Mass Mention')
            .addField('Expires', '12h')

        try {
            msg.author.send(warnEm)

        } catch (err) {

        }


        if (Number.isInteger(warnsJSON[msg.author.id].warns / 3)) {
            var mutedEm = new Discord.MessageEmbed()
                .setColor('RED')
                .setDescription(`**${msg.member.user.username}** has been muted for continuous infractions`)
            msg.channel.send(mutedEm)

            const muteRole = msg.guild.roles.cache.find(r => r.name === 'muted')
            const user = msg.member
            user.roles.add(muteRole.id)

            var yougotmuted = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle(`You have been muted in ${msg.guild.name}`)
                .setDescription('You have been muted after 3 infractions')
                .addField('Reason', 'Multiple AutoMod Infractions')
                .addField('Expires', '1h')

            try {

                msg.author.send(yougotmuted)

            } catch (err) {

            }

            setTimeout(function () {
                user.roles.remove(muteRole.id)
            }, ms('1h'));

        }
        return;

    }
    

    if (msg.content.includes('<@!**YOUR USER ID HERE**>')) {
        msg.delete()
        msg.reply('you cannot ping this user')
    }

    var array = ['fuck', 'fuk', 'penis', 'dick', 'd1ck', 'd!ck', 'pussy', 'boobs', 'boobies', 'nigga', 'nigger', 'bitch', 'b!tch', 'blowjob', 'cock', 'c0ck', 'cunt', 'cnut', 'fucker', 'asshole', 'orgasm', 'masturbation', 'cumshot', 'rape', 'fagg', 'faggot'];

    if (array.some(w => ` ${msg.content.toLowerCase()} `.includes(` ${w} `))) {

        msg.delete()
        msg.reply(`This server does not tolerate that kind of language! Continuing will result in a mute!`)

        var warnsJSON = JSON.parse(Fs.readFileSync('././warnInfo.json'))


        if (!warnsJSON[msg.author.id]) {
            warnsJSON[msg.author.id] = {
                warns: 0
            }

            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }

        warnsJSON[msg.author.id].warns += 1
        Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))


        setTimeout(function () {

            warnsJSON[msg.author.id].warns -= 1
            Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
        }, ms('12h'))

        var warnEm = new Discord.MessageEmbed()
            .setColor('YELLOW')
            .setTitle(`You have been warned in ${msg.guild.name}`)
            .setDescription('You have recieved a warning from the moderation system')
            .addField('Reason', '[AutoMod] Using filtered words')
            .addField('Expires', '12h')

        try {
            msg.author.send(warnEm)

        } catch (err) {

        }


        if (Number.isInteger(warnsJSON[msg.author.id].warns / 3)) {
            var mutedEm = new Discord.MessageEmbed()
                .setColor('RED')
                .setDescription(`**${msg.member.user.username}** has been muted for continuous infractions`)
            msg.channel.send(mutedEm)

            const muteRole = msg.guild.roles.cache.find(r => r.name === 'muted')
            const user = msg.member
            user.roles.add(muteRole.id)

            var yougotmuted = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle(`You have been muted in ${msg.guild.name}`)
                .setDescription('You have been muted after 3 infractions')
                .addField('Reason', 'Multiple AutoMod Infractions')
                .addField('Expires', '1h')

            try {

                msg.author.send(yougotmuted)

            } catch (err) {

            }

            setTimeout(function () {
                user.roles.remove(muteRole.id)
            }, ms('1h'));

        }
        return;

    }

    if (usersMap.has(msg.author.id)) {
        const userData = usersMap.get(msg.author.id);
        const { lastMessage, timer } = userData;
        const difference = msg.createdTimestamp - lastMessage.createdTimestamp;
        let msgCount = userData.msgCount;
        console.log(difference);

        if (difference > DIFF) {
            clearTimeout(timer);
            console.log('Cleared Timeout');
            userData.msgCount = 1;
            userData.lastMessage = msg;
            userData.timer = setTimeout(() => {
                usersMap.delete(msg.author.id);
                console.log('Removed from map.')
            }, TIME);
            usersMap.set(msg.author.id, userData)
        }
        else {
            ++msgCount;
            if (parseInt(msgCount) === LIMIT) {

                msg.reply(`you are not allowed to spam messages in this server. Continuing will result in a mute!`)

                var warnsJSON = JSON.parse(Fs.readFileSync('././warnInfo.json'))


                if (!warnsJSON[msg.author.id]) {
                    warnsJSON[msg.author.id] = {
                        warns: 0
                    }

                    Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
                }

                warnsJSON[msg.author.id].warns += 1
                Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))


                setTimeout(function () {

                    warnsJSON[msg.author.id].warns -= 1
                    Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON))
                }, ms('12h'))

                var warnEm = new Discord.MessageEmbed()
                    .setColor('YELLOW')
                    .setTitle(`You have been warned in ${msg.guild.name}`)
                    .setDescription('You have recieved a warning from the moderation system')
                    .addField('Reason', '[AutoMod] Message Spam')
                    .addField('Expires', '12h')

                try {
                    msg.author.send(warnEm)

                } catch (err) {

                }


                if (Number.isInteger(warnsJSON[msg.author.id].warns / 3)) {
                    var mutedEm = new Discord.MessageEmbed()
                        .setColor('RED')
                        .setDescription(`**${msg.member.user.username}** has been muted for continuous infractions`)
                    msg.channel.send(mutedEm)

                    const muteRole = msg.guild.roles.cache.find(r => r.name === 'muted')
                    const user = msg.member
                    user.roles.add(muteRole.id)

                    var yougotmuted = new Discord.MessageEmbed()
                        .setColor('RED')
                        .setTitle(`You have been muted in ${msg.guild.name}`)
                        .setDescription('You have been muted after 3 infractions')
                        .addField('Reason', 'Multiple AutoMod Infractions')
                        .addField('Expires', '1h')

                    try {

                        msg.author.send(yougotmuted)

                    } catch (err) {

                    }

                    setTimeout(function () {
                        user.roles.remove(muteRole.id)
                    }, ms('1h'));

                }
                return;

            } else {
                userData.msgCount = msgCount;
                usersMap.set(msg.author.id, userData);
            }
        }
    }
    else {
        let fn = setTimeout(() => {
            usersMap.delete(msg.author.id);
            console.log('Removed from map.')
        }, TIME);
        usersMap.set(msg.author.id, {
            msgCount: 1,
            lastMessage: msg,
            timer: fn
        });
    }

})

client.on('guildMemberAdd', async (member) => {

    let warnsJSON = JSON.parse(Fs.readFileSync('././warnInfo.json'));
    warnsJSON[member.id] = {
        warns: 0
    }
    Fs.writeFileSync('././warnInfo.json', JSON.stringify(warnsJSON));
})