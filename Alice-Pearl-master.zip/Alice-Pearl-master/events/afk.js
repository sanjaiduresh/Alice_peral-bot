const client = require('../index')
const { MessageEmbed } = require('discord.js')
const config = require('../config.json')
const prefix = config.prefix
const schema = require('../models/custom-commands');

const mongoDBURL = require('../config.json').mongo;
const { Database } = require('quickmongo');
const quickmongo = new Database(mongoDBURL);

client.on('message', async message => {

    if(await quickmongo.fetch(`afk-${message.author.id}+${message.guild.id}`)) {
        const info = await quickmongo.get(`afk-${message.author.id}+${message.guild.id}`);
        const afkuser = message.member;
        await quickmongo.delete(`afk-${message.author.id}+${message.guild.id}`);
    
        try {
            await afkuser.setNickname(null)
        } catch (err) {
            console.log(err)
        }
    
        message.reply("I've removed your AFK status. Welcome back!")
    }
    
    const mentionedMember = message.mentions.members.first();
    if(mentionedMember) {
        if(await quickmongo.fetch(`afk-${message.mentions.members.first().id}+${message.guild.id}`)) {
            message.reply(`${mentionedMember.user.tag} is now **AFK** with **Reason:** ` + await quickmongo.get(`afk-${message.mentions.members.first().id}+${message.guild.id}`))
        };
    } else return
})
