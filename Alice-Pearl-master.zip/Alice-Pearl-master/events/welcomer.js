const client = require('../index');
const Schema = require('../models/welcomeChannel');
const canvas = require('discord-canvas');
const { MessageAttachment } = require('discord.js');
const Discord = require('discord.js');
const { CanvasSenpai } = require("canvas-senpai")
const canva = new CanvasSenpai();

client.on('guildMemberAdd', async(member) => {
    Schema.findOne({ Guild: member.guild.id }, async(err, data) => {
        if(!data) return;
    
        let datas = await canva.welcome(member, { link: "https://wallpapercave.com/wp/wp4082746.jpg", blur: false})
     
        const attachment = new Discord.MessageAttachment(
          datas,
          "welcome-image.png"
        );

        const welcchannel = member.guild.channels.cache.get(data.Channel);
        welcchannel.send(`<@&761498640480862229> Hey ${member.toString()}, Welcome to **Astral**! Enjoy your time here! <3`,
        attachment);
    })
})