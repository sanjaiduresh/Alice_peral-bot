const { Collection, Client, Discord, MessageEmbed } = require('discord.js')
const fs = require('fs')
const fetch = require("node-fetch");
const DisTube = require("distube");
const client = new Client({
    fetchAllMembers: false,
    restTimeOffset: 0,
    shards: "auto",
    disableEveryone: true
})
const mongoose = require('mongoose')


mongoose.connect('mongodb+srv://Ash:mynameisebron@raven.5gsmq.mongodb.net/Data', {
    useUnifiedTopology: true,
    useNewUrlParser: true,

}).then(console.log('Connected To MongoDB'))

//schema  -----------------------------------------

client.ticketTranscript = mongoose.model('transcripts',
    new mongoose.Schema({
        Channel: String,
        Content: Array
    })
)
// -------------------------------------------------

const blacklist = require('./models/blacklist')


const config = require('./config.json')
const prefix = config.prefix
const token = config.token

const { GiveawaysManager } = require('discord-giveaways');

module.exports = client;
client.commands = new Collection();
client.aliases = new Collection();
client.giveawaysManager = new GiveawaysManager(client, {
    storage: "./giveaways.json",
    updateCountdownEvery: 3000,
    default: {
        botsCanWin: false,
        embedColor: "#FFC0CB",
        reaction: "<:p_tada01:830116068651040839>"
    }
});

const https = require('https-proxy-agent');
const proxy = 'http://123.123.123.123:8080';
const agent = https(proxy);
client.distube = new DisTube(client, {
    youtubeCookie: config.cookie,
    requestOptions: {
        agent
    },
    searchSongs: true,
    emitNewSongOnly: true,
    highWaterMark: 1024 * 1024 * 64,
    leaveOnEmpty: true,
    leaveOnFinish: true,
    leaveOnStop: true,
    searchSongs: false,
    youtubeDL: true,
    updateYouTubeDL: false,
    customFilters: config.customs
})

client.setMaxListeners(0);
require('events').defaultMaxListeners = 0;

client.categories = fs.readdirSync("./commands/");
["command"].forEach(handler => {
    require(`./handlers/${handler}`)(client);
});

require("./handlers/setups")(client)
const functions = require("./functions")

const Enmap = require("enmap");
client.settings = new Enmap({
    name: "settings",
    dataDir: "./databases/settings"
});
client.infos = new Enmap({
    name: "infos",
    dataDir: "./databases/infos"
});
client.custom = new Enmap({
    name: "custom",
    dataDir: "./databases/playlist"
});
client.custom2 = new Enmap({
    name: "custom",
    dataDir: "./databases/playlist2"
});



client.on('message', async (message) => {
    if (message.channel.parentID !== '826025223966294068') return;
    client.ticketTranscript.findOne({ Channel: message.channel.id }, async (err, data) => {
        if (err) throw err;
        if (data) {
            console.log('there is data')
            data.Content.push(`${message.author.tag} : ${message.content}`)
        } else {
            console.log('there is no data')
            data = new client.ticketTranscript({ Channel: message.channel.id, Content: `${message.author.tag} : ${message.content}` })
        }
        await data.save()
            .catch(err => console.log(err))
        console.log('data is saved ')
    })

})

const { thumb, modmailServerId, ticketCategoryID, modmailLogChannelId, mainServerId } = require('./config.json');

var pre = ",";

let rList = {}
var userID;
var reason;
var ticketName;
client.on('message', message => {
    if (message.author.bot || !(message.channel.parentID === ticketCategoryID || message.channel.type === 'dm')) return;
    const serverName = client.guilds.cache.get(mainServerId).name;
    console.log(serverName);

    const argCmd = message.content.slice(pre.length).trim().split(' ');
    const cmd = argCmd.shift().toLowerCase();
    const args = message.content.slice(pre.length + cmd.length).trim().split('/ +/')
    try {
        userID = message.channel.name.split('-').pop();
    }
    catch (err) { userID = message.author.id; }
    if (message.channel.type === 'dm') {
        reason = rList[message.author.id];
        try {

            var ticketNamerep1 = message.author.tag.replace(/#/g, "-");
            ticketName = ticketNamerep1.replace(/ /g, "-").toLowerCase();

            console.log(userID);
            console.log(`${ticketName}-${userID}`/*.split("-").pop()*/);
            const logMailCEmbed = new MessageEmbed();
            logMailCEmbed.setColor('#FFC0CB')
            logMailCEmbed.setAuthor(`${serverName} Support`, client.user.displayAvatarURL())
            logMailCEmbed.setTimestamp()
            logMailCEmbed.setTitle("Ticket Created!")
            logMailCEmbed.setThumbnail(client.user.displayAvatarURL())
            logMailCEmbed.setDescription(`Ticket created by ${message.author.tag}.`)
            if (message.attachments.size > 0) { logMailCEmbed.setImage(message.attachments.first().url) }
            logMailCEmbed.setFooter(`Ticket: ${ticketName} | Subject: ${message.content}`)

            if ((!client.guilds.cache.get(modmailServerId).channels.cache.some(channel => channel.name.split('-').pop() === userID))) {
                rList[message.author.id] = message.content;


                var channel = client.guilds.cache.get(modmailServerId).channels.create(`${ticketName}-${userID}`, { parent: ticketCategoryID });
                channel.then(c => c.setTopic(reason)).then(c => c.send(logMailCEmbed));
                reason = rList[message.author.id];
                const lc = client.channels.fetch(modmailLogChannelId).then(l => { l.send(logMailCEmbed) });

                const createMailEmbed = new MessageEmbed();
                createMailEmbed.setColor('#FFC0CB')
                createMailEmbed.setAuthor(`${serverName} Support`, client.user.displayAvatarURL())
                createMailEmbed.setTimestamp()
                createMailEmbed.setTitle("Ticket Created!")
                createMailEmbed.setThumbnail(client.user.displayAvatarURL())
                createMailEmbed.setDescription('Our support team will be with you shortly!')
                createMailEmbed.setFooter(`Ticket: ${ticketName} | Subject: ${reason}`)

                message.author.send(createMailEmbed);
            }

        }
        catch (err) {
            message.author.send(':x:Too many tickets are open at the moment; please wait a bit and then try again. If you were not creating a ticket, please DM a high ranking staff member with a screenshot of this message.')

            message.react('❌');
            console.log(err);
            return;
        }
        reason = rList[userID];
        message.react('✅');
        const sc = client.guilds.cache.get(modmailServerId).channels.cache.find(channel => channel.name.split("-").pop() === userID);
        const inMailEmbed = new MessageEmbed();
        inMailEmbed.setColor('#FFC0CB')

        inMailEmbed.setAuthor(message.author.tag, message.author.avatarURL())
        inMailEmbed.setTimestamp()
        inMailEmbed.setTitle("Incoming Message!")
        inMailEmbed.setThumbnail(client.user.displayAvatarURL())
        inMailEmbed.setDescription(message.content)
        if (message.attachments.size > 0) { inMailEmbed.setImage(message.attachments.first().url) }

        inMailEmbed.setFooter(`Ticket: ${ticketName} | Subject: ${reason}`)
        const ls = client.channels.fetch(modmailLogChannelId).then(l => { l.send(inMailEmbed) });


        try { sc.send(inMailEmbed); }
        catch (err) { console.log(console.error()) }
        console.log(!(client.guilds.cache.get(modmailServerId).channels.cache.some(channel => channel.name === ticketName)));
    }

    if (message.channel.parentID === ticketCategoryID) {
        if (cmd === "reply" || cmd === "respond" || cmd === 'r') {
            var UID = message.channel.name.split("-").pop();
            var user = client.users.cache.get(`${UID}`);
            reason = rList[userID];
            const outMailEmbed = new MessageEmbed();
            outMailEmbed.setColor('#FFC0CB')
            outMailEmbed.setAuthor(message.author.tag, message.author.avatarURL())
            outMailEmbed.setTimestamp()
            outMailEmbed.setTitle("Reply from Support")
            outMailEmbed.setThumbnail(client.user.displayAvatarURL())
            outMailEmbed.setDescription(args)
            if (message.attachments.size > 0) { outMailEmbed.setImage(message.attachments.first().url) }
            outMailEmbed.setFooter(`Ticket: ${(user.tag.replace(/#/g, '-')).replace(/ /g, '-')} | Subject: ${reason}`)
            const lso = client.channels.fetch(modmailLogChannelId).then(l => { l.send(outMailEmbed) });

            console.log(user);
            console.log(UID);
            try { user.send(outMailEmbed); }
            catch (err) { console.log("error") }
            message.react('📧');
        }
        if (cmd === 'areply' || cmd === 'arespond' || cmd === 'ar') {
            var UID = message.channel.name.split("-").pop();
            var user = client.users.cache.get(`${UID}`);
            reason = rList[userID];
            const outMailEmbed = new MessageEmbed();
            outMailEmbed.setColor('#FFC0CB')
            outMailEmbed.setAuthor('Anonymous Support Member', client.user.displayAvatarURL())
            outMailEmbed.setTimestamp()
            outMailEmbed.setTitle("Reply from Support")
            outMailEmbed.setThumbnail(client.user.displayAvatarURL())
            outMailEmbed.setDescription(args)
            if (message.attachments.size > 0) { outMailEmbed.setImage(message.attachments.first().url) }
            outMailEmbed.setFooter(`Ticket:${(user.tag.replace(/#/g, '-')).replace(/ /g, '-')} | Subject: ${reason}`)
            const outMailEmbedL = new MessageEmbed();
            outMailEmbedL.setColor('#F9A808')
            outMailEmbedL.setAuthor(`[ANONYMOUS REPLY] ${message.author.tag}`, message.author.avatarURL())
            outMailEmbedL.setTimestamp()
            outMailEmbedL.setTitle("Reply from Support")
            outMailEmbedL.setThumbnail(client.user.displayAvatarURL())
            outMailEmbedL.setDescription(args)
            if (message.attachments.size > 0) { outMailEmbedL.setImage(message.attachments.first().url) }
            outMailEmbedL.setFooter(`Ticket: ${(user.tag.replace(/#/g, '-')).replace(/ /g, '-')} | Subject: ${reason}`)
            const lsao = client.channels.fetch(modmailLogChannelId).then(l => { l.send(outMailEmbedL) });
            console.log(user);
            console.log(UID);
            try { user.send(outMailEmbed); }
            catch (err) { console.log("error") }
            message.react('📧');

        }
        if (cmd === 'close' || cmd === 'c') {
            reason = rList[userID];
            var UID = message.channel.name.split("-").pop();
            var user = client.users.cache.get(`${UID}`);
            const closeMailEmbed = new MessageEmbed();
            closeMailEmbed.setColor('#FFC0CB')
            closeMailEmbed.setAuthor(`🔒Locked`, client.user.displayAvatarURL())
            closeMailEmbed.setTimestamp()
            closeMailEmbed.setTitle("Ticket Closed")
            closeMailEmbed.setThumbnail(client.user.displayAvatarURL())
            closeMailEmbed.setDescription("This ticket has been closed.")
            closeMailEmbed.setFooter(`Ticket: ${(user.tag.replace(/#/g, '-')).replace(/ /g, '-')} | Subject: ${reason}`)

            delete rList[UID];
            user.send(closeMailEmbed);
            message.channel.delete();

            const lcs = client.channels.fetch(modmailLogChannelId).then(l => { l.send(closeMailEmbed) });

        }
    }

    ;
});

client.on("message", async (message) => {
    if (!message.guild || message.author.bot || !message.content.trim().startsWith(config.prefix)) return;
    // "!ytt asda" --> "ytt asda" --> ["ytt", "asda"]
    var args = message.content.slice(config.prefix.length).trim().split(" ")
    // ["ytt", "asda"] --> cmd = "ytt" & ["asda"]
    var cmd = args.shift().toLowerCase()

    if (cmd == "ytt" || cmd == "youtubetogether") {

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send("<:excl:819930667974131712> You need to join a Voice Channel")
        fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
            method: "POST",
            body: JSON.stringify({
                max_age: 86400,
                max_uses: 0,
                target_application_id: "755600276941176913",
                target_type: 2,
                temporary: false,
                validate: null
            }),
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": "application/json"
            }
        }).then(res => res.json())
            .then(invite => {
                if (!invite.code) return message.reply("<:excl:819930667974131712> Cannot start activity")
                message.channel.send(`Click on the Link to start watching youtube together:\nhttps://discord.com/invite/${invite.code}`)
            })
    } else if (cmd == "betrayal" || cmd == "betrayal.io") {

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send("<:excl:819930667974131712> You need to join a Voice Channel")
        fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
            method: "POST",
            body: JSON.stringify({
                max_age: 86400,
                max_uses: 0,
                target_application_id: "773336526917861400",
                target_type: 2,
                temporary: false,
                validate: null
            }),
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": "application/json"
            }
        }).then(res => res.json())
            .then(invite => {
                if (!invite.code) return message.reply("<:excl:819930667974131712> Cannot start activity")
                message.channel.send(`Click on the Link to start the GAME:\nhttps://discord.com/invite/${invite.code}`)
            })
    } else if (cmd == "poker" || cmd == "poker-night") {

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send("<:excl:819930667974131712> You need to join a Voice Channel")
        fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
            method: "POST",
            body: JSON.stringify({
                max_age: 86400,
                max_uses: 0,
                target_application_id: "755827207812677713",
                target_type: 2,
                temporary: false,
                validate: null
            }),
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": "application/json"
            }
        }).then(res => res.json())
            .then(invite => {
                if (!invite.code) return message.reply("<:excl:819930667974131712> Cannot start activity")
                message.channel.send(`Click on the Link to start the GAME:\nhttps://discord.com/invite/${invite.code}`)
            })
    } else if (cmd == "fishing" || cmd == "fishington.io") {

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send("<:excl:819930667974131712> You need to join a Voice Channel")
        fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
            method: "POST",
            body: JSON.stringify({
                max_age: 86400,
                max_uses: 0,
                target_application_id: "814288819477020702",
                target_type: 2,
                temporary: false,
                validate: null
            }),
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": "application/json"
            }
        }).then(res => res.json())
            .then(invite => {
                if (!invite.code) return message.reply("<:excl:819930667974131712> Cannot start activity")
                message.channel.send(`Click on the Link to start the GAME:\nhttps://discord.com/invite/${invite.code}`)
            })
    } else {
        return
    }
})

client.on('message', message => {

    if (message.content === 'Welcome :)' || message.content === 'Welcome' || message.content === 'Welcome!' || message.content === 'welcome' || message.content === 'welcome!' || message.content === 'welcome :)') {
        if (message.channel.id != '825970297496010752') return
        message.channel.send('<a:starries:808170508386041906><a:welcome1:762331103766904893><a:welcome2:762331125473345576><a:starries:808170508386041906>')
    }
})

client.login(token)